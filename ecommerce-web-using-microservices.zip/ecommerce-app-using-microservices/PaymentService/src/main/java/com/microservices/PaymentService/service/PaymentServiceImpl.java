package com.microservices.PaymentService.service;

import com.microservices.PaymentService.entity.TransactionDetails;
import com.microservices.PaymentService.model.PaymentRequest;
import com.microservices.PaymentService.repository.PaymentRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@Log4j2
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    PaymentRepository paymentRepository;

    @Override
    public long doPayment(PaymentRequest paymentRequest) {
         log.info(" doing payment .....");

        TransactionDetails transactionDetails = TransactionDetails.builder()
                .orderId(paymentRequest.getOrderId())
                        .paymentMode(paymentRequest.getPaymentMode())
                                .amount(paymentRequest.getAmount())
                                        .referenceNumber(paymentRequest.getReferenceNumber())
                                                .paymentDate(Instant.now())
                                                        .paymentStatus("SUCCESS")
                                                                .build();
        paymentRepository.save(transactionDetails);
        log.info(" payment done successfully .... ");
        return transactionDetails.getId();
    }
}
