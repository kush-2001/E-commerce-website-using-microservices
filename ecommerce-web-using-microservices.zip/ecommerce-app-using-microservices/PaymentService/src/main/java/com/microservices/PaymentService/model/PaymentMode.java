package com.microservices.PaymentService.model;

public enum PaymentMode {
    CASH,
    UPI,
    DEBIT_CARD,
    CREDIT_CARD
}
