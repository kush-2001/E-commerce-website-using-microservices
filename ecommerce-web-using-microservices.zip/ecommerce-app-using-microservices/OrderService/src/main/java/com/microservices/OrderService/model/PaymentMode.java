package com.microservices.OrderService.model;

public enum PaymentMode {
    CASH,
    UPI,
    DEBIT_CARD,
    CREDIT_CARD
}
