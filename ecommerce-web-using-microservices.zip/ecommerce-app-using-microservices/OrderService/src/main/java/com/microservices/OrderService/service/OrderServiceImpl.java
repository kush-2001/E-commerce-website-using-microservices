package com.microservices.OrderService.service;

import com.microservices.OrderService.entity.Order;
import com.microservices.OrderService.external.client.PaymentService;
import com.microservices.OrderService.external.client.ProductService;
import com.microservices.OrderService.external.request.PaymentRequest;
import com.microservices.OrderService.model.OrderRequest;
import com.microservices.OrderService.model.OrderResponse;
import com.microservices.OrderService.repository.OrderRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;

@Service
@Log4j2
public class OrderServiceImpl implements OrderService{

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    ProductService productService;

    @Autowired
    PaymentService paymentService;

    @Override
    public Long placeOrder(OrderRequest orderRequest) {

        log.info(" placing order ..... ");

        log.info(" calling product service for productId {} and quantity {} ",orderRequest.getProductId(),orderRequest.getQuantity());
        productService.reduceQuantity(orderRequest.getProductId() , orderRequest.getQuantity());

        Order order = Order.builder()
                .productId(orderRequest.getProductId())
                .quantity(orderRequest.getQuantity())
                .amount(orderRequest.getAmount())
                .orderStatus("CREATED")
                .orderDate(Instant.now())
                .build();
        orderRepository.save(order);

        PaymentRequest paymentRequest = PaymentRequest.builder()
                .orderId(order.getOrderId())
                .paymentMode(orderRequest.getPaymentMode())
                .amount(orderRequest.getAmount())
                .build();
        try{
            paymentService.doPayment(paymentRequest);
            log.info(" payment successfully ....");
            order.setOrderStatus("PLACED");
        }catch (Exception e){
            log.info(" payment Failed ....");
            order.setOrderStatus("PAYMENT_CANCELLED");
        }
        orderRepository.save(order);
        log.info(" order placed successfully .... ");
        return order.getOrderId();
    }

    @Override
    public Object getOrderDetails(long orderId) {
        log.info(" getting order details for order id "+orderId);

        Order order = orderRepository.findById(orderId)
                .orElse(null);

        OrderResponse orderResponse = null;
        if(order!=null) {
            orderResponse = OrderResponse.builder()
                    .orderId(order.getOrderId())
                    .orderDate(order.getOrderDate())
                    .orderStatus(order.getOrderStatus())
                    .amount(order.getAmount())
                    .quantity(order.getQuantity())
                    .build();
        }
        return orderResponse;

    }
}
