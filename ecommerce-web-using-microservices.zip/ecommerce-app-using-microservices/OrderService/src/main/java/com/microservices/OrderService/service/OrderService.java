package com.microservices.OrderService.service;

import com.microservices.OrderService.model.OrderRequest;

public interface OrderService {
    Long placeOrder(OrderRequest orderRequest);

    Object getOrderDetails(long orderId);
}
