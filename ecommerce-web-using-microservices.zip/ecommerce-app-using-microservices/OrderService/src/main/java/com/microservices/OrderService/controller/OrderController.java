package com.microservices.OrderService.controller;

import com.microservices.OrderService.model.OrderRequest;
import com.microservices.OrderService.model.OrderResponse;
import com.microservices.OrderService.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping("/place-order")
    public ResponseEntity<Long> placeOrder(@RequestBody OrderRequest orderRequest){
        Long orderId = orderService.placeOrder(orderRequest);
        return new ResponseEntity(orderId , HttpStatus.OK);
    }

    @GetMapping("/order-details")
    public ResponseEntity<OrderResponse> getOrderDatails(@RequestParam("order-id") long orderId){
        return new ResponseEntity(
                orderService.getOrderDetails(orderId),
                HttpStatus.OK
        );
    }
}
