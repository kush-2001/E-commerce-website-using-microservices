package com.microservices.service;

import com.microservices.model.ProductRequest;
import com.microservices.model.ProductResponse;

public interface ProductService {
    long addProduct(ProductRequest productRequest);

    ProductResponse getProductById(long productId);

    void reduceQuantity(long productId, long quantity);
}
