package com.microservices.controller;

import com.microservices.model.ProductRequest;
import com.microservices.model.ProductResponse;
import com.microservices.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    ProductService productService;

    @PostMapping("/add-product")
    public ResponseEntity<Long> addProduct(@RequestBody ProductRequest productRequest){
        long productId = productService.addProduct(productRequest);
        return new ResponseEntity(productId , HttpStatus.CREATED);
    }

    @GetMapping("/get-product")
    public ResponseEntity<ProductResponse> getProductById(@RequestParam("product-id") long productId){
        ProductResponse productResponse = productService.getProductById(productId);
        return new ResponseEntity(productResponse , HttpStatus.OK);
    }

    @PutMapping("/reduce-quantity")
    public ResponseEntity<Void>  reduceQuantity(
            @RequestParam("productId") long productId ,
            @RequestParam("quantity") long quantity
    ){
        productService.reduceQuantity(productId,quantity);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
